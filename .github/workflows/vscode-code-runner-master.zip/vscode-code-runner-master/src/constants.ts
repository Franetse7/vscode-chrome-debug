"use strict";

export class Constants {
    public static readonly python = "python";
}
